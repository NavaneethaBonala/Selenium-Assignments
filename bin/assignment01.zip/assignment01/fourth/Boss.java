package assignment01.fourth;


public class Boss extends Employee{

	public  Boss(long id, String name, String address, long phone, double salary) {
		super(id, name, address, phone, salary);
	}
	
}