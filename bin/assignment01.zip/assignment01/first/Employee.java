package assignment01.first;

public class Employee {
	
	long employeeId;
	String employeeName;
	String employeeAddress;
	String employee;
	long employeePhone;
	double basicSalary;
	double specialAllowance = 250.80;
	double HRA = 1000.50;

}